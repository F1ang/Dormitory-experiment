#ifndef _DELAY_H
#define _DELAY_H

#include <reg52.h>
typedef unsigned int u16;
typedef unsigned char u8;
void delay(u16 i);
void UsartInit();
#endif