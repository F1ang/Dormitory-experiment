#ifndef _LED_H
#define _LED_H

#include <reg52.h>
sbit led1=P2^0;
sbit led2=P2^1;
sbit led3=P2^2;
sbit led4=P2^3;
sbit led5=P2^4;
sbit led6=P2^5;
sbit led7=P2^6;
sbit led8=P2^7;
sbit s1=P3^1;
sbit s2=P3^0;
void check_led8();
#endif