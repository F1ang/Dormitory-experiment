#include "led.h"
#include "delay.h"
void check_led8()
{
    led1=0;	
	delay(50000);
    led2=0;
    delay(50000);
    led3=0;	
	delay(50000);
    led4=0;
    delay(50000);
    led5=0;	
	delay(50000);
    led6=0;
    delay(50000);
    led7=0;	
	delay(50000);
    led8=0;
    delay(50000);//��

    led1=1;	
	delay(50000);
    led2=1;
    delay(50000);
    led3=1;	
	delay(50000);
    led4=1;
    delay(50000);
    led5=1;	
	delay(50000);
    led6=1;
    delay(50000);
    led7=1;	
	delay(50000);
    led8=1;
    delay(50000);//��
}




