#include "shuma.h"
void scan(u8 can);
void scan1(u8 can1);
void scan2(u8 can2,u8 dip);
u8 i;
u8 code smgduan[17]={0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,
					0x7f,0x6f,0x77,0x7c,0x39,0x5e,0x79,0x71};//��ʾ0~F��ֵ
void check_shuma()
{
	u16 j;u8 come=0; 
    for(j=0;j<1;j++)
    {
      if(come==0){scan(1);come++;}
         delay(50000);
      if(come==1){scan(2);come++;}
      	delay(50000);
      if(come==2){scan(3);come++;}
      	delay(50000);
      if(come==3){scan(4);come++;}
      	delay(50000);
      if(come==4){scan(5);come++;}
      	delay(50000);
      if(come==5){scan(6);come++;}
      	delay(50000);
      if(come==6){scan(7);come++;}
      	delay(50000);
      if(come==7){scan(8);come++;come=0;}
      	delay(50000);
        P0=0x00;//����  
    } //ʵ������
   for(j=0;j<1;j++)
    {
      if(come==0){scan1(0);come++;}
         delay(50000);
      if(come==1){scan1(1);come++;}
      	delay(50000);
      if(come==2){scan1(2);come++;}
      	delay(50000);
      if(come==3){scan1(3);come++;}
      	delay(50000);
      if(come==4){scan1(4);come++;}
      	delay(50000);
      if(come==5){scan1(5);come++;}
      	delay(50000);
      if(come==6){scan1(6);come++;}
      	delay(50000);
      if(come==7){scan1(7);come++;come=0;}
      	delay(50000);
        P0=0x00;//����  
    } ////ʵ���ҵ���
}
void scan(u8 can)
{
    u16 ref;
   for(ref=0;ref<5000;ref++)
   {
  	for(i=0;i<can;i++)
	  {
		switch(i)
		{
		   case(0):
				LSA=1;LSB=1;LSC=1; break;//��ʾ��0λ
			case(1):
				LSA=0;LSB=1;LSC=1; break;//��ʾ��1λ
			case(2):
				LSA=1;LSB=0;LSC=1; break;//��ʾ��2λ
			case(3):	
				LSA=0;LSB=0;LSC=1; break;//��ʾ��3λ
			case(4):
				LSA=1;LSB=1;LSC=0; break;//��ʾ��4λ
			case(5):
				LSA=0;LSB=1;LSC=0; break;//��ʾ��5λ
			case(6):
				LSA=1;LSB=0;LSC=0; break;//��ʾ��6λ
			case(7):
				LSA=0;LSB=0;LSC=0; break;//��ʾ��7λ	
		}
        P0=smgduan[1];	
		P0=0x00;//����
	  }
    }
      
}
void scan1(u8 can1)
{
    u16 ref1;
    for(ref1=0;ref1<5000;ref1++){
  	for(i=can1;i<8;i++)
	{
		switch(i)
		{
		   case(0):
				LSA=1;LSB=1;LSC=1; break;//��ʾ��0λ
			case(1):
				LSA=0;LSB=1;LSC=1; break;//��ʾ��1λ
			case(2):
				LSA=1;LSB=0;LSC=1; break;//��ʾ��2λ
			case(3):	
				LSA=0;LSB=0;LSC=1; break;//��ʾ��3λ
			case(4):
				LSA=1;LSB=1;LSC=0; break;//��ʾ��4λ
			case(5):
				LSA=0;LSB=1;LSC=0; break;//��ʾ��5λ
			case(6):
				LSA=1;LSB=0;LSC=0; break;//��ʾ��6λ
			case(7):
				LSA=0;LSB=0;LSC=0; break;//��ʾ��7λ	
		}
        P0=smgduan[1];	
		P0=0x00;//����
	}
    }  
}
void scan2(u8 can2,u8 dip)
{
u16 j;
  for(j=0;j<100;j++)
  {
   	for(i=can2;i<8;i++)
	{
		switch(i)
		{
		   case(0):
				LSA=1;LSB=1;LSC=1; break;//��ʾ��0λ
			case(1):
				LSA=0;LSB=1;LSC=1; break;//��ʾ��1λ
			case(2):
				LSA=1;LSB=0;LSC=1; break;//��ʾ��2λ
			case(3):	
				LSA=0;LSB=0;LSC=1; break;//��ʾ��3λ
			case(4):
				LSA=1;LSB=1;LSC=0; break;//��ʾ��4λ
			case(5):
				LSA=0;LSB=1;LSC=0; break;//��ʾ��5λ
			case(6):
				LSA=1;LSB=0;LSC=0; break;//��ʾ��6λ
			case(7):
				LSA=0;LSB=0;LSC=0; break;//��ʾ��7λ	
		}
        P0=dip;	
		P0=0x00;//����
	 }
    }
}