#ifndef _SHUMA_H
#define _SHUMA_H

#include <reg52.h>
#include "delay.h"
sbit LSA=P2^2;//38
sbit LSB=P2^3;
sbit LSC=P2^4;
void check_shuma();
void scan(u8 can);
void scan1(u8 can1);
void scan2(u8 can2,u8 dip);
#endif